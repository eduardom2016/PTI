function validartrabalho() {
    var tit = document.querySelector("#tt").value;
    var descricao = document.querySelector("#descricao").value;
    var dados = 0;


    if (tit.length < 5) {
        alert('Digite um título com no mínimo 4 caracteres!');
        document.querySelector('#tt').focus();
        dados = 1;
        return false;
    }



    if (descricao.length < 10) {
        alert('Digite uma descrição com no mínimo 10 caracteres!');
        document.querySelector('#descricao').focus();
        dados = 1;
        return false;
    }


    if (dados == 0) {
        alert('Trabalho enviado com Sucesso!');
    }


}
