SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

CREATE SCHEMA IF NOT EXISTS `consciencia` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci ;
CREATE SCHEMA IF NOT EXISTS `consciencia` DEFAULT CHARACTER SET utf8 ;
USE `consciencia` ;

-- -----------------------------------------------------
-- Table `consciencia`.`tipoUsuario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `consciencia`.`tipoUsuario` (
  `idTipo` INT NOT NULL AUTO_INCREMENT,
  `nomeUsuario` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idTipo`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `consciencia`.`usuario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `consciencia`.`usuario` (
  `idUsuario` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NOT NULL,
  `email` VARCHAR(45) NOT NULL,
  `senha` VARCHAR(45) NOT NULL,
  `idTipo` INT NOT NULL,
  PRIMARY KEY (`idUsuario`),
  INDEX `fk_usuario_tipoUsuario_idx` (`idTipo` ASC),
  CONSTRAINT `fk_usuario_tipoUsuario`
    FOREIGN KEY (`idTipo`)
    REFERENCES `consciencia`.`tipoUsuario` (`idTipo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `consciencia`.`tipoConteudo`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `consciencia`.`tipoConteudo` (
  `idTipoConteudo` INT NOT NULL AUTO_INCREMENT,
  `nomeConteudo` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idTipoConteudo`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `consciencia`.`disciplina`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `consciencia`.`disciplina` (
  `idDisciplina` INT NOT NULL,
  `nomeDisciplina` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idDisciplina`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `consciencia`.`conteudo`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `consciencia`.`conteudo` (
  `idConteudo` INT NOT NULL AUTO_INCREMENT,
  `dataConteudo` DATE NOT NULL,
  `textoConteudo` BLOB NOT NULL,
  `idTipoConteudo` INT NOT NULL,
  `idUsuario` INT NOT NULL,
  `idDisciplina` INT NOT NULL,
  PRIMARY KEY (`idConteudo`),
  INDEX `fk_conteudo_tipoConteudo1_idx` (`idTipoConteudo` ASC),
  INDEX `fk_conteudo_usuario1_idx` (`idUsuario` ASC),
  INDEX `fk_conteudo_disciplina1_idx` (`idDisciplina` ASC),
  CONSTRAINT `fk_conteudo_tipoConteudo1`
    FOREIGN KEY (`idTipoConteudo`)
    REFERENCES `consciencia`.`tipoConteudo` (`idTipoConteudo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_conteudo_usuario1`
    FOREIGN KEY (`idUsuario`)
    REFERENCES `consciencia`.`usuario` (`idUsuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_conteudo_disciplina1`
    FOREIGN KEY (`idDisciplina`)
    REFERENCES `consciencia`.`disciplina` (`idDisciplina`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `consciencia`.`comentario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `consciencia`.`comentario` (
  `idComentario` INT NOT NULL AUTO_INCREMENT,
  `dataComentario` DATE NOT NULL,
  `textoComentario` VARCHAR(45) NULL,
  `idUsuario` INT NOT NULL,
  `idConteudo` INT NOT NULL,
  PRIMARY KEY (`idComentario`),
  INDEX `fk_comentario_usuario1_idx` (`idUsuario` ASC),
  INDEX `fk_comentario_conteudo1_idx` (`idConteudo` ASC),
  CONSTRAINT `fk_comentario_usuario1`
    FOREIGN KEY (`idUsuario`)
    REFERENCES `consciencia`.`usuario` (`idUsuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_comentario_conteudo1`
    FOREIGN KEY (`idConteudo`)
    REFERENCES `consciencia`.`conteudo` (`idConteudo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `consciencia`.`table1`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `consciencia`.`table1` (
)
ENGINE = InnoDB;

USE `consciencia` ;

-- -----------------------------------------------------
-- Table `consciencia`.`tipoUsuario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `consciencia`.`tipoUsuario` (
  `idTipo` INT NOT NULL AUTO_INCREMENT,
  `nomeUsuario` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idTipo`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `consciencia`.`usuario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `consciencia`.`usuario` (
  `idUsuario` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(45) NOT NULL,
  `email` VARCHAR(45) NOT NULL,
  `senha` VARCHAR(45) NOT NULL,
  `idTipo` INT NOT NULL,
  PRIMARY KEY (`idUsuario`),
  INDEX `fk_usuario_tipoUsuario_idx` (`idTipo` ASC),
  CONSTRAINT `fk_usuario_tipoUsuario`
    FOREIGN KEY (`idTipo`)
    REFERENCES `consciencia`.`tipoUsuario` (`idTipo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `consciencia`.`tipoConteudo`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `consciencia`.`tipoConteudo` (
  `idTipoConteudo` INT NOT NULL AUTO_INCREMENT,
  `nomeConteudo` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`idTipoConteudo`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `consciencia`.`conteudo`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `consciencia`.`conteudo` (
  `idConteudo` INT NOT NULL AUTO_INCREMENT,
  `dataConteudo` DATE NOT NULL,
  `textoConteudo` BLOB NOT NULL,
  `idTipoConteudo` INT NOT NULL,
  `idUsuario` INT NOT NULL,
  PRIMARY KEY (`idConteudo`),
  INDEX `fk_conteudo_tipoConteudo1_idx` (`idTipoConteudo` ASC),
  INDEX `fk_conteudo_usuario1_idx` (`idUsuario` ASC),
  CONSTRAINT `fk_conteudo_tipoConteudo1`
    FOREIGN KEY (`idTipoConteudo`)
    REFERENCES `consciencia`.`tipoConteudo` (`idTipoConteudo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_conteudo_usuario1`
    FOREIGN KEY (`idUsuario`)
    REFERENCES `consciencia`.`usuario` (`idUsuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `consciencia`.`comentario`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `consciencia`.`comentario` (
  `idComentario` INT NOT NULL AUTO_INCREMENT,
  `dataComentario` DATE NOT NULL,
  `textoComentario` VARCHAR(45) NULL DEFAULT NULL,
  `idUsuario` INT NOT NULL,
  `idConteudo` INT NOT NULL,
  PRIMARY KEY (`idComentario`),
  INDEX `fk_comentario_usuario1_idx` (`idUsuario` ASC),
  INDEX `fk_comentario_conteudo1_idx` (`idConteudo` ASC),
  CONSTRAINT `fk_comentario_usuario1`
    FOREIGN KEY (`idUsuario`)
    REFERENCES `consciencia`.`usuario` (`idUsuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_comentario_conteudo1`
    FOREIGN KEY (`idConteudo`)
    REFERENCES `consciencia`.`conteudo` (`idConteudo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `consciencia`.`disciplina`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `consciencia`.`disciplina` (
  `idDisciplina` INT NOT NULL,
  `nomeDisciplina` VARCHAR(45) NOT NULL,
  `conteudo_idConteudo` INT NOT NULL,
  PRIMARY KEY (`idDisciplina`),
  INDEX `fk_disciplina_conteudo1_idx` (`conteudo_idConteudo` ASC),
  CONSTRAINT `fk_disciplina_conteudo1`
    FOREIGN KEY (`conteudo_idConteudo`)
    REFERENCES `consciencia`.`conteudo` (`idConteudo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
