function validar(){
var nome = document.querySelector("#nome").value;
var email = document.querySelector("#email").value;
var senha = document.querySelector("#senha").value;
var rep_senha = document.querySelector("#repsenha").value;
var dados = 0;


if (nome == "") {
alert('Preencha o campo com seu nome!');
document.querySelector('#nome').focus();
dados = 1;
return false;
}



if (nome.length < 5) {
alert('Digite seu nome completo!');
document.querySelector('#nome').focus();
dados = 1;
return false;
}

if (senha != rep_senha) {
alert('Senhas diferentes!');
document.querySelector('#senha').focus();
dados = 1;
return false;
}

if (senha == "") {
alert('Preencha o campo com sua senha!');
document.querySelector('#senha').focus();
dados = 1;
return false;
}


if(dados == 0){
alert('Cadastrado com Sucesso!');
}


}
