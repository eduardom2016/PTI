function validarcadastro(){
var nome = document.querySelector("#nome").value;
var email = document.querySelector("#email").value;
var senha = document.querySelector("#senha").value;
var rep_senha = document.querySelector("#repsenha").value;
var dados = 0;


if (nome == "") {
alert('Campo em branco!');
document.querySelector('#nome').focus();
dados = 1;
return false;
}



if (nome.length < 4 ) {
alert('Digite seu nome!');
document.querySelector('#nome').focus();
dados = 1;
return false;
}

if (senha != rep_senha) {
alert('Senhas diferentes!');
document.querySelector('#senha').focus();
dados = 1;
return false;
}

if (senha == "") {
alert('Campo em branco!');
document.querySelector('#senha').focus();
dados = 1;
return false;
}


if(dados == 0){
alert('Cadastrado com Sucesso!');
}


}
