function validartrabalho(){
var titulo = document.querySelector("#titulo").value;
var descricao = document.querySelector("#descricao").value;
var dados = 0;


if (titulo == "") {
alert('Campo em branco!');
document.querySelector('#titulo').focus();
dados = 1;
return false;
}


if (titulo.length < 5 ) {
alert('Título insuficiente!');
document.querySelector('#nome').focus();
dados = 1;
return false;
}



if (descricao == "") {
alert('Campo em branco!');
document.querySelector('#senha').focus();
dados = 1;
return false;
}

if (descricao.length < 5 ) {
alert('Descrição insuficiente!');
document.querySelector('#nome').focus();
dados = 1;
return false;
}


if(dados == 0){
alert('Cadastrado com Sucesso!');
}


}
