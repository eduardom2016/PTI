<?php
	require_once 'init.php';
	include_once 'usuario.class.php';
	
	
	// pega os dados do formulário
	$nome = isset ($_POST['nome'])?$_POST['nome']:null;
	$email = isset ($_POST['email'])?$_POST['email']:null;
	$senha = isset ($_POST['senha'])?$_POST['senha']:null ;


function validaEmail($email) {

if (preg_match(
'/^[^0-9][a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[@][a-zA-Z0-9_]+([.][a-zA-Z0-9_]+)*[.][a-zA-Z]{2,4}$/',
$email)) {
return true;
}
else {
	return false;
}
}
 
 
	// validação simples se campos estão vazios
	if( empty ( $nome ) || empty ( $email) || empty ( $senha)){
		echo "Campos devem ser preenchidos!!";
		
		exit ;
	}
	
	if(!validaEmail($email)){
		echo "Email incorreto!!";
		exit;
	}
	

	
	
	// instancia objeto aluno
	$usuario = new usuario($nome,$email,$senha);

	// insere no BD
	$PDO = db_connect() ;
	$sql = "INSERT INTO usuario(nome,email,senha) VALUES (:nome , :email , :senha)";
	$stmt = $PDO->prepare($sql);
	$stmt->bindParam(':nome' ,$usuario->getNome());
	$stmt->bindParam(':email' ,$usuario->getEmail());
	$stmt->bindParam(':senha' ,$usuario->getSenha());
	if($stmt->execute()){
		header ('Location: ../filosofia.html');
	}else{
		echo "Erro ao cadastrar!!";
		print_r( $stmt->errorInfo());
	}
?>
