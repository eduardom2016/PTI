$(document).ready(function (e) {
    $("#java li").click(function (e) {
        e.preventDefault();
        var href = $(this).attr('href');
        $("#conteudoajax").load(href + " #conteudoajax");
    });
});
