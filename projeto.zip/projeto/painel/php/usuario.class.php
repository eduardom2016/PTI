<?php

class usuario {

    //decarando variaveis//
    private $nome;
    private $email;
    private $senha;
    private $idTipo;

    //construtor//
    public function __construct($nome, $email, $senha, $idTipo) {
        $this->setNome($nome);
        $this->setEmail($email);
        $this->setSenha($senha);
        $this->setidTipo($idTipo);
    }

    //pega e entrega NOME//
    public function setNome($nome) {
        $this->nome = $nome;
    }

    public function getNome() {
        return $this->nome;
    }

    //pega e entrega EMAIL//
    public function setEmail($email) {
        $this->email = $email;
    }

    public function getEmail() {
        return $this->email;
    }

    //pega e entrega DATA CADASTRO//
    public function setSenha($senha) {
        $this->senha = $senha;
    }

    public function getSenha() {
        return $this->senha;
    }
    
     public function setidTipo($idTipo) {
        $this->idTipo = $idTipo;
    }

    public function getidTipo() {
        return $this->idTipo;
    }

}

?>
