<?php

class adicionar {

    //decarando variaveis//
    private $titulo;
    private $imagem;
    private $postagem;
    private $tipo;

    //construtor//
    public function __construct($titulo, $imagem, $postagem, $tipo) {
        $this->setTitulo($titulo);
        $this->setImagem($imagem);
        $this->setPostagem($postagem);
         $this->setTipo($tipo);
    }

    //pega e entrega titulo//
    public function setTitulo($titulo) {
        $this->titulo = $titulo;
    }

    public function getTitulo() {
        return $this->titulo;
    }

    //pega e entrega imagem//
    public function setImagem($imagem) {
        $this->imagem = $imagem;
    }

    public function getImagem() {
        return $this->imagem;
    }

    //pega e entrega DATA CADASTRO//
    public function setPostagem($postagem) {
        $this->postagem = $postagem;
    }

    public function getPostagem() {
        return $this->postagem;
    }
    
    public function setTipo($tipo) {
        $this->tipo = $tipo;
    }

    public function getTipo() {
        return $this->tipo;
    }

}

?>
