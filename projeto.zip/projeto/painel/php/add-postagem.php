<?php
session_start();
require_once 'init.php';
include_once 'adicionar.class.php';


// pega os dados do formulário
$titulo = isset($_POST['titulo']) ? $_POST['titulo'] : null;
$imagem = isset($_POST['imagem']) ? $_POST['imagem'] : null;
$postagem = isset($_POST['postagem']) ? $_POST['postagem'] : null;
$disciplina = isset($_POST['disciplina']) ? $_POST['disciplina'] : null;
$categoria = isset($_POST['categoria']) ? $_POST['categoria'] : null;




// instancia objeto aluno


// insere no BD
$PDO = db_connect();

	print_r($_SESSION); 
	
	//Inserir título da postagem:	
    $sql = "INSERT INTO conteudo (tituloConteudo,enderecoImagem,textoConteudo,idDisciplina,idTipoConteudo, idUsuario) VALUES (:titulo , :imagem , :postagem, :disciplina, :categoria, :idUsuario)";
    $stmt = $PDO->prepare($sql);
    $stmt->bindParam(':titulo', $titulo);
    $stmt->bindParam(':imagem', $imagem);
    $stmt->bindParam(':postagem', $postagem);
     $stmt->bindParam(':disciplina', $disciplina);
      $stmt->bindParam(':categoria', $categoria);
       $stmt->bindParam(':idUsuario', $_SESSION["idUsuario"]);
      
    if ($stmt->execute()) {
        header('Location: ../index.html');
    } else {
        echo "Erro ao cadastrar!!";
        print_r($stmt->errorInfo());
    }
    
   
//}
?>
