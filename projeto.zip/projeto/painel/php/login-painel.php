<?php

session_start();
require_once 'init.php';
include_once 'adicionar.class.php';

$email = isset($_POST['email']) ? $_POST['email'] : null;
$senha = isset($_POST['senha']) ? $_POST['senha'] : null;
$tipo = isset($_POST['tipo']) ? $_POST['tipo'] : null;


$PDO = db_connect();
$sql = "SELECT * FROM usuario WHERE email = :email AND senha = :senha AND idTipo= :tipo";
$stmt = $PDO->prepare($sql);
$stmt->bindParam(':email', $email);
$stmt->bindParam(':senha', sha1($senha));
$stmt->bindParam(':tipo', $tipo);
$stmt->execute();

//echo $senha;
//echo $email;
//echo $tipo;
//echo $stmt->rowCount();

if (($stmt->rowCount() > 0) && ($tipo==="1") ) {
	//$_SESSION['login'] = $login;
	$result = $stmt->fetchAll();
    $_SESSION['email'] = $email;  
    $_SESSION['idUsuario'] = $result[0]["idUsuario"];   
    header('location: ../index.html');
       
}
 else {
    //unset ($_SESSION['login']);
    unset($_SESSION['email']);
    unset($_SESSION['idTipo']);
    
   header('location:../../aa/index.html');
}
?>
