<?php

require_once 'init.php';
include_once 'usuario.class.php';


// pega os dados do formulário
$nome = isset($_POST['nome']) ? $_POST['nome'] : null;
$email = isset($_POST['email']) ? $_POST['email'] : null;
$senha = isset($_POST['senha']) ? $_POST['senha'] : null;
$repsenha = isset($_POST['repsenha']) ? $_POST['repsenha'] : null;



// instancia objeto aluno
$usuario = new usuario($nome, $email, $senha);

// insere no BD
$PDO = db_connect();
$sql1 = "SELECT email FROM usuario WHERE email=:email";
$stmt1 = $PDO->prepare($sql1);
$stmt1->bindParam(':email', $email);
$stmt1->execute();
$variavel = $stmt1->rowCount();
if (($variavel > 0)) {
    echo"<meta charset='utf-8'><script>alert('Email já cadastrado!');window.history.back();</script>";
} else {
    $sql = "INSERT INTO usuario(nome,email,senha) VALUES (:nome , :email , :senha)";
    $stmt = $PDO->prepare($sql);
    $stmt->bindParam(':nome', $usuario->getNome());
    $stmt->bindParam(':email', $usuario->getEmail());
    $stmt->bindParam(':senha', sha1($usuario->getSenha()));
    if ($stmt->execute()) {
        header('Location: ../index.html');
    } else {
        echo "Erro ao cadastrar!!";
        print_r($stmt->errorInfo());
    }
}
?>
