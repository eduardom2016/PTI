<?php

session_start();
require_once 'init.php';
include_once 'usuario.class.php';

$email = isset($_POST['email']) ? $_POST['email'] : null;
$senha = isset($_POST['senha']) ? $_POST['senha'] : null;

$PDO = db_connect();
$sql = "SELECT * FROM usuario WHERE email = :email AND senha = :senha";
$stmt = $PDO->prepare($sql);
$stmt->bindParam(':email', $email);
$stmt->bindParam(':senha', sha1($senha));
$stmt->execute();

if ($stmt->rowCount() > 0) {
//$_SESSION['login'] = $login;
    $_SESSION['email'] = $email;

    header('location:../index.html');
} else {
    //unset ($_SESSION['login']);
    unset($_SESSION['email']);

    header('location:../filosofia.html');
}
?>
