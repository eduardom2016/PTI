function validarcadastro() {
    var nome = document.querySelector("#nome").value;
    var email = document.querySelector("#email").value;
    var senha = document.querySelector("#senha").value;
    var rep_senha = document.querySelector("#repsenha").value;
    var dados = 0;


    if (nome.length < 4) {
        alert('Digite um nome com no mínimo 4 caracteres!');
        document.querySelector('#nome').focus();
        dados = 1;
        return false;
    }

    if (senha.length < 6) {
        alert('Digite uma senha com no mínimo 6 caracteres!');
        document.querySelector('#senha').focus();
        dados = 1;
        return false;
    }

    if (senha != rep_senha) {
        alert('Senhas diferentes!');
        document.querySelector('#senha').focus();
        dados = 1;
        return false;
    }

    if (senha == "") {
        alert('Campo em branco!');
        document.querySelector('#senha').focus();
        dados = 1;
        return false;
    }


//if(dados == 0){
//alert('Cadastrado com Sucesso!');
//}


}

