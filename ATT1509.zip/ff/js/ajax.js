$(document).ready(function(e){
	$("#menuTopo a").click(function(e){
		e.preventDefault();
		var href = $(this).attr('href');
		$("#conteudoajax").load(href + " #conteudoajax");
	});
});

$(document).ready(function(e){
	$("#menuTopo1 a").click(function(e){
		e.preventDefault();
		var href = $(this).attr('href');
		$("#conteudoajax").load(href + " #conteudoajax");
	});
});
