function validartrabalho(){
var tit = document.querySelector("#tt").value;
var descricao = document.querySelector("#descricao").value;
var dados = 0;


if (tit == "") {
alert('Campo em branco!');
document.querySelector('#tt').focus();
dados = 1;
return false;
}


if (tit.length < 5 ) {
alert('Título insuficiente!');
document.querySelector('#nome').focus();
dados = 1;
return false;
}



if (descricao == "") {
alert('Campo em branco!');
document.querySelector('#senha').focus();
dados = 1;
return false;
}

if (descricao.length < 5 ) {
alert('Descrição insuficiente!');
document.querySelector('#nome').focus();
dados = 1;
return false;
}


if(dados == 0){
alert('Cadastrado com Sucesso!');
}


}
